import connexion
import json
from db_setup import DB_SESSION
from db_setup import engine
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models import temperatureEvent, motionEvent
from base import Base
from datetime import datetime
from threading import Lock
from connexion import NoContent

def postTemperatureEvent(body):
    
    session = DB_SESSION()

    timestamp = datetime.utcnow()

    temp = temperatureEvent(body['device_id'],
                            body['temperature'],
                            timestamp,
                            body['event_type'])

    session.add(temp)
    session.commit()
    session.close()

    return NoContent, 201

def postMotionEvent(body):
    
    session = DB_SESSION()

    timestamp = datetime.utcnow()

    motion = motionEvent(body['device_id'],
                            body['room'],
                            timestamp,
                            body['motion_intensity'])

    session.add(motion)
    session.commit()
    session.close()

    return NoContent, 201

app = connexion.FlaskApp(__name__, specification_dir='.')
app.add_api("receiver.yml", strict_validation=True, validate_responses=True)

if __name__ == "__main__":
    app.run(port=8090)