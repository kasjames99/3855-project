from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models import Base

engine = create_engine("sqlite:///events.sqlite")
Base.metadata.bind = engine
Base.metadata.drop_all(engine)
Base.metadata.create_all(engine)
DB_SESSION = sessionmaker(bind=engine)