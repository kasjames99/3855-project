import connexion
import json
import yaml
import logging
import logging.config
from db_setup import DB_SESSION
from db_setup import engine
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models import temperatureEvent, motionEvent
from base import Base
from datetime import datetime, timezone
from threading import Lock
from connexion import NoContent

with open('log_conf.yml', 'r') as f:
    log_config = yaml.safe_load(f.read())
    logging.config.dictConfig(log_config)

logger = logging.getLogger('basicLogger')

def postTemperatureEvent(body):
    
    session = DB_SESSION()

    timestamp = datetime.utcnow()

    temp = temperatureEvent(device_id=body['device_id'],
                            temperature=body['temperature'],
                            timestamp=timestamp,
                            event_body=body['event_type'],
                            trace_id=body['trace_id']
                            )

    session.add(temp)
    session.commit()
    session.close()

    logger.debug(f"Stored event temperature with trace id: {body['trace_id']}")

    return NoContent, 201

def postMotionEvent(body):
    
    session = DB_SESSION()

    timestamp = datetime.utcnow()

    motion = motionEvent(device_id=body['device_id'],
                            room=body['room'],
                            motion_intensity=body['motion_intensity'],
                            timestamp=timestamp,
                            trace_id=body['trace_id'],)

    session.add(motion)
    session.commit()
    session.close()

    logger.debug(f"Stored event motion with trace id: {body['trace_id']}")

    return NoContent, 201

app = connexion.FlaskApp(__name__, specification_dir='.')
app.add_api("receiver.yml", strict_validation=True, validate_responses=True)

if __name__ == "__main__":
    app.run(port=8090)