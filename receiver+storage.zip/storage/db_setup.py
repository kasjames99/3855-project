import yaml
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models import Base

with open("app_conf.yaml", "r") as f:
    app_config = yaml.safe_load(f.read())

db_user = app_config["datastore"]["user"]
db_password = app_config["datastore"]["password"]
db_host = app_config["datastore"]["hostname"]
db_port = app_config["datastore"]["port"]
db_name = app_config["datastore"]["db"]

DB_URL = f"mysql+pymysql://{db_user}:{db_password}@{db_host}:{db_port}/{db_name}"

engine = create_engine(DB_URL)
Base.metadata.bind = engine
Base.metadata.drop_all(engine)
Base.metadata.create_all(engine)
DB_SESSION = sessionmaker(bind=engine)