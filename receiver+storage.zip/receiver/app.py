import connexion
import json
import httpx
import time
import yaml
import logging
import logging.config
from datetime import datetime
from threading import Lock
from connexion import NoContent

with open("log_conf.yml", "r") as f:
    log_config = yaml.safe_load(f.read())
    logging.config.dictConfig(log_config)

with open('app_conf.yml', 'r') as f:
    app_config = yaml.safe_load(f.read())

logger = logging.getLogger("basicLogger")

def log_event(event_type, event_body):

    trace_id = time.time_ns()

    logger.info(f"Received event {event_type} with a trace ID of {trace_id}")

    if event_type == "temperature":
        event_data = {
            "trace_id": trace_id,
            "device_id": event_body["device_id"],
            "temperature": event_body["temperature"],
            "event_type": event_body["event_type"],
        }
        STORAGE_URL = app_config["events"]["temperature"]["url"]
        
    elif event_type == "motion":
        event_data = {
            "trace_id": trace_id,
            "device_id": event_body["device_id"],
            "room": event_body.get("room", "default_room"),
            "motion_intensity": event_body.get("motion_intensity", 0),
        }
        STORAGE_URL = app_config["events"]["motion"]["url"]
    
    try:
        response = httpx.post(STORAGE_URL, json=event_data)

        logger.info(
            f"Response for event {event_type} (trace ID: {trace_id}) has status {response.status_code}"
        )

        if response.status_code == 201:
            return NoContent, 201 
        else:
            return {"error": "Failed to store event data"}, response.status_code
    except httpx.RequestError as e:
        logger.error(f"Request failed for event {event_type} (trace ID: {trace_id}): {e}")
        return {"error": f"Request failed: {e}"}, 500


def postTemperatureEvent(body):
    return log_event("temperature", body)

def postMotionEvent(body):
    return log_event("motion", body)

app = connexion.FlaskApp(__name__, specification_dir='.')
app.add_api("receiver.yml", strict_validation=True, validate_responses=True)

if __name__ == "__main__":
    logger.info("Starting Receiver Service")
    app.run(port=8081)